# Bayesian Linear Regression and Linear Regression

For this project, I used a single file function based structure. The layout is as follows.

main.py - This file holds the functions for training bayesian linear regression and linear regression and executes the models on the various tasks printing the output to the console.

pp2data/ - This folder holds the data used throughout to project.

report/ - The report folder consists of a written report discussing the codes output.

output/ - The output folder contains any graphs created in the project.

